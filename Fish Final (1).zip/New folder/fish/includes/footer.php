<div class="bg-info p-3 text-center p-0">
   <p>All rights reserved ©- Designed by Team White House BUBT</p>
   </div>